/*
 * Copyright (c) 2010-2011 Mark Allen.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package com.restfb.example;

import static org.apache.log4j.Logger.getLogger;

import org.apache.log4j.Logger;
import org.slf4j.bridge.SLF4JBridgeHandler;

import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.types.User;

/**
 * Example which shows how to route RestFB's java.util.logging statements to Log4j.
 * 
 * @author <a href="http://restfb.com">Mark Allen</a>
 */
public class Log4jBridgeExample {
  private static final Logger logger = getLogger(Log4jBridgeExample.class);

  /**
   * Runs the app. Make sure you tell the JVM about the java.util.logging config file by passing along the parameter
   * "-Djava.util.logging.config.file=logging.properties". The Log4j config file should be picked up automatically.
   * 
   * @param args
   *          Command-line arguments (ignored).
   */
  public static void main(String[] args) {
    // You'll want to initialize the bridge just once at app startup.
    // In a webapp, a good place to do this is ContextLoaderListener#contextInitialized()
    SLF4JBridgeHandler.install();

    try {
      FacebookClient facebookClient = new DefaultFacebookClient();

      // You'll notice that logging statements from this call are bridged from java.util.logging to Log4j
      User user = facebookClient.fetchObject("btaylor", User.class);

      // ...and of course this goes straight to Log4j
      logger.debug(user);
    } finally {
      // Make sure to tear down when you're done using the bridge
      SLF4JBridgeHandler.uninstall();
    }
  }
}